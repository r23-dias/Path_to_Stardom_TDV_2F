﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace Path_to_stardom_TDV
{
    public class Camera
    {
        private Vector2 _position;
        private float _zoom;
        private readonly Viewport _viewport;
        private readonly float _minZoom = 0.5f;
        private readonly float _maxZoom = 2f;
        private readonly float _smoothness = 0.1f;

        public Vector2 Position => _position;

        public Camera(Viewport viewport, Vector2 initialPosition)
        {
            _viewport = viewport;
            _position = initialPosition;
            _zoom = 1f; // Zoom inicial
        }

        public Matrix TransformMatrix =>
            Matrix.CreateTranslation(new Vector3(-_position, 0)) *
            Matrix.CreateScale(_zoom) *
            Matrix.CreateTranslation(new Vector3(_viewport.Width / 2, _viewport.Height / 2, 0));

        public void Update(Vector2 player1Pos, Vector2 player2Pos)
        {
            // Ponto médio entre os dois players (X e Y)
            float midpointX = (player1Pos.X + player2Pos.X) / 2f;
            float midpointY = (player1Pos.Y + player2Pos.Y) / 2f;

            // Aplicar limites verticais se necessário
            float minY = 0f; // Limite superior
            float maxY = 350f; // Limite inferior

            midpointY = MathHelper.Clamp(midpointY, minY, maxY);

            // Aplicar suavização para ambos os eixos
            Vector2 targetPosition = new Vector2(midpointX, midpointY);
            _position = Vector2.Lerp(_position, targetPosition, _smoothness);

            // Calcular zoom baseado na distância entre os jogadores
            float horizontalDistance = Math.Abs(player1Pos.X - player2Pos.X);
            float verticalDistance = Math.Abs(player1Pos.Y - player2Pos.Y);

            float margin = 400f; // margem para não ficar colado na borda

            // Espaço necessário horizontal para mostrar ambos os players + margem
            float requiredWidth = horizontalDistance + margin * 2;

            // Espaço necessário vertical para mostrar ambos os players + margem
            float requiredHeight = verticalDistance + margin * 2;

            // Calcula o zoom necessário para que esse espaço caiba no viewport
            float desiredZoomX = _viewport.Width / requiredWidth;
            float desiredZoomY = _viewport.Height / requiredHeight;

            // Usa o menor zoom para garantir que ambos os players fiquem visíveis
            float desiredZoom = Math.Min(desiredZoomX, desiredZoomY);

            _zoom = MathHelper.Clamp(desiredZoom, _minZoom, _maxZoom);
        }
    }
}