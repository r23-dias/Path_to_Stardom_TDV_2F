﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Path_to_stardom_TDV
{
    public class VictoryScreen
    {
        private Texture2D _backgroundTexture;
        private BitmapFont _font;
        private int _winner;
        private Vector2 _titlePosition;
        private Vector2 _optionPosition;
        private Color _titleColor = Color.Gold;
        private Color _optionColor = Color.White;

        public void SetWinner(int playerNumber)
        {
            _winner = playerNumber;
        }

        public void LoadContent(ContentManager content, GraphicsDevice graphicsDevice)
        {
            _font = new BitmapFont(graphicsDevice);
            _backgroundTexture = CreateVictoryBackground(graphicsDevice);

            // Posicionar elementos centralizados na tela de 1280x720
            _titlePosition = new Vector2(640 - 150, 250); // Centralizado
            _optionPosition = new Vector2(640 - 200, 400); // Centralizado
        }

        private Texture2D CreateVictoryBackground(GraphicsDevice graphicsDevice)
        {
            Texture2D texture = new Texture2D(graphicsDevice, 1280, 720);
            Color[] data = new Color[1280 * 720];
            for (int i = 0; i < data.Length; i++)
                data[i] = Color.Black * 0.8f; // Fundo semi-transparente
            texture.SetData(data);
            return texture;
        }

        public int Update(GameTime gameTime, KeyboardState currentKeyboard, KeyboardState previousKeyboard)
        {
            if (currentKeyboard.IsKeyDown(Keys.Enter) && !previousKeyboard.IsKeyDown(Keys.Enter))
            {
                return 1; // Retorna para o menu principal
            }
            return -1;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            // Desenhar background começando em (0,0)
            Vector2 bgPosition = new Vector2(0, 0);
            spriteBatch.Draw(_backgroundTexture, bgPosition, Color.White);

            // Desenhar título de vitória
            string victoryText = $"PLAYER {_winner} WINS!";
            _font.DrawText(spriteBatch, victoryText, _titlePosition, _titleColor, 3f);

            // Desenhar opção para continuar
            _font.DrawText(spriteBatch, "PRESSIONE ENTER PARA CONTINUAR", _optionPosition, _optionColor, 2f);
        }
    }
}
